# Sistema de gestión de asistencia usando PHP y MySQL
<img src="Sistema-de-gestion-de-asistencia-usando-PHP-y-MySQL.png">

El proyecto es de control de asistencia aplicable para colegios, academias de educación superior, universidades, entre otros.

El funcionamiento de la apliclación se explica en el siguiente enlace:

https://www.configuroweb.com/sistema-de-gestion-de-asistencia-usando-php-y-mysql/

La aplicación tiene un coste de 15 USD. Necesitas la base de datos para que esté 100% funcional. En el siguiente enlace está el proyecto para que hagas las pruebas que consideres pertinentes:

https://mauriciosevilla.com/asistencia/index.php

El usuario de pruebas es configuroweb y la contraseña 1234abcd..

Si te interesa la apliclación puedes comprarla por paypal en la siguiente cuenta msevillab@gmail.com

Me puedes contactar al whatsapp en el siguiente enlace

https://configuroweb.com/WhatsappMessenger
