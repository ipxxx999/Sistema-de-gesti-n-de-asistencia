<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = 'Admin123.';
	$dbDatabase = 'asistencia';

	$adminConfig = array(
		'adminUsername' => "administrador",
		'adminPassword' => "4b67deeb9aba04a5b54632ad19934f26",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "guest",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Nombre Completo",
		'custom2' => "Dirección",
		'custom3' => "Ciudad",
		'custom4' => "Departamento",
		'MySQLDateFormat' => "%m/%d/%Y",
		'PHPDateFormat' => "n/j/Y",
		'PHPDateTimeFormat' => "m/d/Y, h:i a",
		'senderName' => "",
		'senderEmail' => "admin@admin.com",
		'approvalSubject' => "Su membresía ahora está aprobada",
		'approvalMessage' => "Querido miembro,\r\n\r\nSu membresía ahora está aprobada por el administrador. Puede iniciar sesión en su cuenta aquí:\r\nhttp://localhost/asistencia\r\n\r\nRegards,\r\nAdmin",
		'hide_twitter_feed' => "",
		'maintenance_mode_message' => "<b>Nuestro sitio web está actualmente fuera de servicio por mantenimiento</b><br>\r\nEsperamos estar de regreso en un par de horas. Gracias por su paciencia.",
		'mail_function' => "mail",
		'smtp_server' => "",
		'smtp_encryption' => "",
		'smtp_port' => "25",
		'smtp_user' => "",
		'smtp_pass' => ""
	);